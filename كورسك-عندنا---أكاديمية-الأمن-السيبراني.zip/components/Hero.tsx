
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Cpu, ShieldCheck, Sparkles } from 'lucide-react';

interface HeroProps {
  onExplore: () => void;
}

const Hero: React.FC<HeroProps> = ({ onExplore }) => {
  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-[95vh] md:min-h-screen flex items-center justify-center pt-24 md:pt-20 overflow-hidden px-4 md:px-6">
      {/* Background elements */}
      <div className="absolute top-1/4 -right-1/4 w-72 h-72 md:w-96 md:h-96 bg-[#4a9e9e]/15 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-1/4 -left-1/4 w-72 h-72 md:w-96 md:h-96 bg-[#f9c80e]/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-8 md:gap-12 items-center relative z-10 w-full">
        <div className="text-center md:text-right order-2 md:order-1">
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 bg-[#4a9e9e]/10 border border-[#4a9e9e]/20 px-4 py-1.5 rounded-full mb-6 mx-auto md:mr-0">
              <Sparkles className="w-3 h-3 text-[#f9c80e]" />
              <span className="text-[10px] md:text-xs font-mono text-[#4a9e9e] uppercase tracking-widest font-bold">Digital Future Academy</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold text-white leading-[1.15] mb-6">
              كورسك عندنا<br />
              <span className="text-[#4a9e9e] neon-text leading-relaxed">بوابتك للقمة التقنية</span>
            </h1>
            
            <p className="text-base md:text-xl text-slate-400 mb-8 md:mb-10 max-w-xl md:mr-0 mx-auto leading-relaxed">
              تعلم البرمجة، الأمن السيبراني، والذكاء الاصطناعي من نخبة الخبراء بشرح عملي وتطبيقي لبناء مستقبلك المهني.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-[#4a9e9e] text-[#071a1a] px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 shadow-[0_10px_30px_rgba(74,158,158,0.3)] transition-all order-1"
                onClick={onExplore}
              >
                تصفح جميع المسارات
                <ArrowLeft className="w-5 h-5" />
              </motion.button>
              
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-[#0d2626]/50 border border-slate-700 hover:border-[#4a9e9e]/50 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all backdrop-blur-sm order-2"
                onClick={scrollToAbout}
              >
                لماذا نحن؟
              </motion.button>
            </div>
          </motion.div>
        </div>

        <motion.div 
          className="relative order-1 md:order-2 flex justify-center"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          <div className="relative w-full max-w-[300px] sm:max-w-[350px] md:max-w-none">
            <motion.div
              animate={{ 
                rotate: [0, 1, -1, 0],
                y: [0, -15, 0]
              }}
              transition={{ 
                duration: 6, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
              className="relative z-10"
            >
              <div className="aspect-square w-full md:w-80 lg:w-[420px] bg-[#0d2626] rounded-[2.5rem] md:rounded-[3.5rem] border-2 border-[#4a9e9e]/40 flex items-center justify-center shadow-[0_0_60px_rgba(74,158,158,0.25)] overflow-hidden group">
                <img 
                  src="https://a.top4top.io/p_3666wf9ae1.jpeg" 
                  alt="Koursak Indana Logo" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#071a1a]/40 to-transparent pointer-events-none" />
              </div>
              
              {/* Floating mobile elements */}
              <motion.div 
                animate={{ y: [0, 15, 0] }}
                transition={{ duration: 4, repeat: Infinity, delay: 0.5 }}
                className="absolute -top-4 -right-4 md:-top-10 md:-right-10 bg-[#f9c80e] p-3 md:p-5 rounded-2xl shadow-2xl border border-white/20 z-20"
              >
                 <ShieldCheck className="w-6 h-6 md:w-8 md:h-8 text-[#071a1a]" />
              </motion.div>
              
              <motion.div 
                animate={{ y: [0, -15, 0] }}
                transition={{ duration: 5, repeat: Infinity }}
                className="absolute -bottom-4 -left-4 md:-bottom-8 md:-left-8 bg-[#4a9e9e] p-3 md:p-5 rounded-2xl shadow-2xl border border-white/20 z-20"
              >
                 <Cpu className="w-6 h-6 md:w-8 md:h-8 text-[#071a1a]" />
              </motion.div>
            </motion.div>

            <motion.div 
              animate={{ rotate: -360 }}
              transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
              className="absolute -inset-8 md:-inset-24 border border-[#4a9e9e]/10 rounded-full border-dashed"
            />
          </div>
        </motion.div>
      </div>
      
      <div className="absolute bottom-0 left-0 w-full h-40 bg-gradient-to-t from-[#071a1a] to-transparent z-10" />
    </section>
  );
};

export default Hero;
