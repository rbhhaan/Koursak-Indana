
import React from 'react';
import { motion } from 'framer-motion';
import { Menu, Home, Compass, Phone, Info } from 'lucide-react';

interface NavbarProps {
  onNavigate: (page: 'home' | 'explorer') => void;
  activePage: 'home' | 'explorer';
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, activePage }) => {
  const whatsappLink = "https://wa.me/message/VBFZEYE4ZZZWA1";

  const scrollToAbout = () => {
    onNavigate('home');
    setTimeout(() => {
      const element = document.getElementById('about');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <>
      {/* Desktop & Mobile Top Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 p-4 md:p-6 lg:px-12 pointer-events-none">
        <motion.div 
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="max-w-7xl mx-auto flex items-center justify-between bg-[#0d2626]/90 backdrop-blur-xl border border-[#4a9e9e]/20 px-5 md:px-8 py-3 md:py-4 rounded-2xl md:rounded-full shadow-[0_8px_32px_rgba(0,0,0,0.4)] pointer-events-auto"
        >
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="w-10 h-10 md:w-12 md:h-12 bg-[#071a1a] rounded-xl flex items-center justify-center border border-[#4a9e9e]/30 overflow-hidden shadow-inner">
              <img 
                src="https://a.top4top.io/p_3666wf9ae1.jpeg" 
                alt="Logo" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-lg md:text-xl font-black text-white leading-none tracking-tighter">كورسك <span className="text-[#4a9e9e]">عندنا</span></span>
              <span className="text-[8px] md:text-[10px] text-[#f9c80e] font-bold uppercase tracking-widest mt-0.5">Digital Future</span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-6 lg:gap-8">
            <button 
              onClick={() => onNavigate('home')}
              className={`flex items-center gap-2 text-sm font-bold transition-all ${activePage === 'home' ? 'text-[#f9c80e]' : 'text-slate-300 hover:text-[#4a9e9e]'}`}
            >
              <Home className="w-4 h-4" />
              الرئيسية
            </button>
            <button 
              onClick={() => onNavigate('explorer')}
              className={`flex items-center gap-2 text-sm font-bold transition-all ${activePage === 'explorer' ? 'text-[#f9c80e]' : 'text-slate-300 hover:text-[#4a9e9e]'}`}
            >
              <Compass className="w-4 h-4" />
              تصفح المسارات
            </button>
            <button 
              onClick={scrollToAbout}
              className="flex items-center gap-2 text-slate-300 hover:text-[#4a9e9e] transition-all text-sm font-bold"
            >
              <Info className="w-4 h-4" />
              من نحن؟
            </button>
            <a 
              href={whatsappLink} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-slate-300 hover:text-[#4a9e9e] transition-all text-sm font-bold"
            >
              <Phone className="w-4 h-4" />
              اتصل بنا
            </a>
          </div>

          {/* Mobile Right Icons Container */}
          <div className="flex md:hidden items-center gap-2">
            <a 
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-[#f9c80e] bg-[#f9c80e]/10 rounded-lg border border-[#f9c80e]/20"
            >
              <Phone className="w-5 h-5" />
            </a>
            <button className="p-2 text-[#4a9e9e] bg-[#0d2626] rounded-lg border border-[#4a9e9e]/20">
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      </nav>

      {/* Mobile Bottom Navigation (App-like feel) */}
      <div className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] w-[90%] max-w-[400px]">
        <div className="bg-[#0d2626]/90 backdrop-blur-2xl border border-[#4a9e9e]/30 rounded-2xl flex items-center justify-around py-3 px-2 shadow-[0_10px_40px_rgba(0,0,0,0.6)]">
          <button 
            onClick={() => onNavigate('home')}
            className={`flex flex-col items-center gap-1 transition-all ${activePage === 'home' ? 'text-[#f9c80e]' : 'text-slate-400'}`}
          >
            <Home className="w-6 h-6" />
            <span className="text-[10px] font-bold">الرئيسية</span>
          </button>
          <button 
            onClick={() => onNavigate('explorer')}
            className={`flex flex-col items-center gap-1 transition-all ${activePage === 'explorer' ? 'text-[#f9c80e]' : 'text-slate-400'}`}
          >
            <Compass className="w-6 h-6" />
            <span className="text-[10px] font-bold">المسارات</span>
          </button>
          <button 
            onClick={scrollToAbout}
            className="flex flex-col items-center gap-1 text-slate-400"
          >
            <Info className="w-6 h-6" />
            <span className="text-[10px] font-bold">من نحن؟</span>
          </button>
          <a 
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center gap-1 text-slate-400 active:text-[#f9c80e]"
          >
            <Phone className="w-6 h-6" />
            <span className="text-[10px] font-bold">اتصل</span>
          </a>
        </div>
      </div>
    </>
  );
};

export default Navbar;
