
import React from 'react';
import { motion } from 'framer-motion';
import { Users, ShieldCheck, Zap, Star, Trophy, Target, History, Globe2, CheckCircle } from 'lucide-react';

const stats = [
  { label: "طالب مسجل", value: "+5,000", icon: <Users className="w-5 h-5" /> },
  { label: "مدرب خبير", value: "25+", icon: <Star className="w-5 h-5" /> },
  { label: "دورة معتمدة", value: "+100", icon: <Trophy className="w-5 h-5" /> },
];

const featureData = [
  {
    title: "مناهج عالمية محدثة",
    desc: "نحدث دروسنا أسبوعياً لتواكب سرعة التغير في عالم التكنولوجيا والذكاء الاصطناعي.",
    icon: <Target className="w-8 h-8" />,
    color: "from-[#4a9e9e] to-[#2d6161]"
  },
  {
    title: "تطبيق عملي 100%",
    desc: "لا نكتفي بالشرح النظري؛ كل دورة تتضمن مشاريع حقيقية تبني بها معرض أعمالك الاحترافي.",
    icon: <ShieldCheck className="w-8 h-8" />,
    color: "from-[#f9c80e] to-[#b8950a]"
  },
  {
    title: "دعم فني وتوجيه مهني",
    desc: "نحن معك خطوة بخطوة، من بداية التعلم وحتى الحصول على وظيفة أحلامك في كبرى الشركات.",
    icon: <Zap className="w-8 h-8" />,
    color: "from-[#4a9e9e] to-[#2d6161]"
  }
];

const Features: React.FC = () => {
  return (
    <section id="features" className="py-24 px-4 md:px-6 bg-[#071a1a] relative overflow-hidden">
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* About Us Section */}
        <div id="about" className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center mb-32 scroll-mt-32">
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1"
          >
            <div className="inline-flex items-center gap-2 bg-[#f9c80e]/10 border border-[#f9c80e]/20 px-4 py-1.5 rounded-full mb-6">
              <History className="w-4 h-4 text-[#f9c80e]" />
              <span className="text-xs font-bold text-[#f9c80e] uppercase tracking-wider">من نحن؟</span>
            </div>
            <h2 className="text-3xl md:text-5xl font-black text-white mb-6 leading-[1.2]">
              أكاديمية <span className="text-[#4a9e9e]">كورسك عندنا</span><br />
              رؤية تقنية تقود المستقبل
            </h2>
            <p className="text-slate-400 text-lg leading-relaxed mb-6">
              نحن لسنا مجرد منصة دورات، بل مجتمع تقني متكامل يهدف إلى صناعة الجيل القادم من خبراء التكنولوجيا العرب. تأسست "كورسك عندنا" برؤية واضحة: جعل التعليم التقني المتقدم متاحاً، عملياً، ومواكباً لأعلى المعايير العالمية.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {[
                "تدريب عملي على مشاريع حقيقية",
                "شهادات معتمدة محلياً ودولياً",
                "متابعة دورية مع المدربين",
                "دخول مدى الحياة للمحتوى"
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="bg-[#4a9e9e]/10 p-1 rounded-full border border-[#4a9e9e]/20">
                    <CheckCircle className="w-4 h-4 text-[#4a9e9e]" />
                  </div>
                  <span className="text-slate-300 font-medium text-sm">{item}</span>
                </div>
              ))}
            </div>

            <p className="text-slate-400 text-lg leading-relaxed">
              نحن نؤمن بأن المستقبل رقمي بالكامل، ولذلك نركز على تزويد طلابنا بالمهارات التي يحتاجها سوق العمل اليوم، من الأمن السيبراني العميق إلى هندسة الذكاء الاصطناعي وتطوير البرمجيات المعقدة.
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="order-1 lg:order-2 grid grid-cols-2 gap-4 relative"
          >
            {/* Background Glow for Image Grid */}
            <div className="absolute inset-0 bg-[#4a9e9e]/5 blur-[80px] rounded-full pointer-events-none" />
            
            <div className="space-y-4 relative z-10">
              <div className="aspect-square bg-[#0d2626] border border-[#4a9e9e]/20 rounded-3xl flex flex-col items-center justify-center p-6 text-center shadow-lg group hover:border-[#4a9e9e] transition-all">
                <Globe2 className="w-10 h-10 text-[#4a9e9e] mb-4 group-hover:scale-110 transition-transform" />
                <h4 className="text-white font-bold mb-1">تعليم بلا حدود</h4>
                <p className="text-[10px] text-slate-500 uppercase tracking-tighter">Global Digital Reach</p>
              </div>
              <div className="aspect-[3/4] bg-[#4a9e9e] rounded-3xl overflow-hidden shadow-2xl relative group">
                 <img 
                  src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=400" 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 scale-110 group-hover:scale-100" 
                  alt="Cyber Lab"
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-[#071a1a]/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
            
            <div className="space-y-4 pt-12 relative z-10">
               <div className="aspect-[3/4] bg-[#0d2626] rounded-3xl overflow-hidden border border-white/5 group shadow-xl">
                 <img 
                  src="https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=400" 
                  className="w-full h-full object-cover opacity-50 group-hover:opacity-100 transition-all duration-700" 
                  alt="AI Development"
                 />
               </div>
               <div className="aspect-square bg-[#f9c80e] rounded-3xl flex flex-col items-center justify-center p-6 text-center shadow-[0_15px_40px_rgba(249,200,14,0.3)]">
                  <h4 className="text-[#071a1a] text-4xl font-black mb-1">+25</h4>
                  <p className="text-[#071a1a] text-xs font-black uppercase tracking-widest">Partner</p>
               </div>
            </div>
          </motion.div>
        </div>

        {/* Why Us Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-black text-white mb-6">لماذا نحن الخيار <span className="text-[#4a9e9e]">الأول</span> للمبدعين؟</h2>
          <div className="w-24 h-1 bg-[#f9c80e] mx-auto rounded-full" />
        </motion.div>

        {/* Stats Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 md:gap-8 mb-20">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-[#0d2626]/80 backdrop-blur-md border border-[#4a9e9e]/10 p-7 rounded-3xl flex items-center justify-between shadow-2xl group hover:border-[#4a9e9e]/40 transition-all"
            >
              <div>
                <p className="text-[#4a9e9e] font-mono text-[11px] uppercase tracking-widest mb-1 font-bold group-hover:text-[#f9c80e] transition-colors">{stat.label}</p>
                <p className="text-3xl font-black text-white">{stat.value}</p>
              </div>
              <div className="p-4 bg-[#4a9e9e]/15 rounded-2xl text-[#f9c80e] shadow-inner group-hover:scale-110 transition-transform">
                {stat.icon}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Features Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {featureData.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2 }}
              whileHover={{ y: -12 }}
              className="p-8 md:p-12 rounded-[2.5rem] bg-[#0d2626] border border-[#4a9e9e]/10 hover:border-[#4a9e9e]/60 transition-all duration-500 relative group overflow-hidden shadow-2xl"
            >
              <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
                {f.icon}
              </div>
              
              <div className={`w-18 h-18 md:w-20 md:h-20 rounded-3xl bg-gradient-to-br ${f.color} flex items-center justify-center text-[#071a1a] mb-8 shadow-2xl group-hover:rotate-6 transition-transform`}>
                {React.cloneElement(f.icon as React.ReactElement, { className: "w-10 h-10" })}
              </div>
              
              <h3 className="text-2xl font-black text-white mb-4 group-hover:text-[#4a9e9e] transition-colors leading-tight">
                {f.title}
              </h3>
              
              <p className="text-slate-400 leading-relaxed text-base mb-8">
                {f.desc}
              </p>
              
              <div className="mt-auto flex items-center gap-3 text-[#4a9e9e] text-sm font-bold cursor-pointer group/link">
                <span className="group-hover/link:text-[#f9c80e] transition-colors">تعرف على التفاصيل</span>
                <div className="w-10 h-px bg-[#4a9e9e]/30 group-hover/link:bg-[#f9c80e] group-hover/link:w-16 transition-all" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Dynamic Background elements */}
      <div className="absolute -top-60 -left-60 w-[500px] h-[500px] bg-[#4a9e9e]/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute -bottom-60 -right-60 w-[500px] h-[500px] bg-[#f9c80e]/5 rounded-full blur-[140px] pointer-events-none" />
    </section>
  );
};

export default Features;
