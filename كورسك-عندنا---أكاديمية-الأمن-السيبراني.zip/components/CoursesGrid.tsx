
import React from 'react';
import { motion } from 'framer-motion';
import { Code, BrainCircuit, Smartphone, Layout, Cloud, ShieldAlert, ArrowUpRight } from 'lucide-react';

interface CoursesGridProps {
  onExplore: () => void;
}

const techCourses = [
  {
    id: 1,
    title: "برمجة المواقع",
    desc: "من React إلى Node.js؛ تعلم بناء المواقع الأكثر طلباً.",
    icon: <Code className="w-8 h-8" />,
    size: "md:col-span-1",
    bg: "bg-[#4a9e9e]/5"
  },
  {
    id: 2,
    title: "الأمن السيبراني",
    desc: "تعلم الحماية واختبار الاختراق وتأمين السيرفرات.",
    icon: <ShieldAlert className="w-8 h-8" />,
    size: "md:col-span-1",
    bg: "bg-[#f9c80e]/5"
  },
  {
    id: 3,
    title: "الذكاء الاصطناعي",
    desc: "نماذج الـ ML وتطوير التطبيقات الذكية العصرية.",
    icon: <BrainCircuit className="w-8 h-8" />,
    size: "md:col-span-1",
    bg: "bg-[#4a9e9e]/5"
  }
];

const CoursesGrid: React.FC<CoursesGridProps> = ({ onExplore }) => {
  return (
    <section id="courses" className="py-24 px-6 bg-[#071a1a]">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-4">مسارات <span className="text-[#4a9e9e]">المستقبل</span> التقني</h2>
            <p className="text-slate-400 max-w-lg">مناهج تعليمية شاملة تغطي كافة تخصصات التكنولوجيا الحديثة.</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <button 
              onClick={onExplore}
              className="text-[#f9c80e] font-bold border-b-2 border-[#f9c80e]/30 hover:border-[#f9c80e] pb-1 transition-all"
            >
              استكشف جميع المسارات
            </button>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {techCourses.map((course, i) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -5 }}
              onClick={onExplore}
              className={`cursor-pointer group relative overflow-hidden rounded-[2rem] border border-slate-800 hover:border-[#4a9e9e]/40 p-8 transition-all duration-500 bg-[#0d2626]`}
            >
              <div className="relative z-10">
                <div className="text-[#4a9e9e] mb-6 p-3 bg-[#4a9e9e]/10 inline-block rounded-xl group-hover:bg-[#f9c80e] group-hover:text-[#071a1a] transition-all">
                  {course.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-[#4a9e9e] transition-colors">{course.title}</h3>
                <p className="text-slate-400 text-sm mb-6">{course.desc}</p>
                <div className="flex items-center gap-2 text-xs text-cyan-400 font-bold uppercase tracking-wider">
                  <span>ابدأ الآن</span>
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CoursesGrid;
