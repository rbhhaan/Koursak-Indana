
import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Instagram, Facebook, Mail } from 'lucide-react';

const Contact: React.FC = () => {
  const whatsappLink = "https://wa.me/message/VBFZEYE4ZZZWA1";
  const instagramLink = "https://www.instagram.com/3_8s4?igsh=MXAydjMyb2oxOG1hMA==";
  const facebookLink = "https://www.facebook.com/share/17uLMUGcvM/";

  return (
    <section id="contact" className="py-24 px-6 relative bg-[#071a1a]">
      <div className="max-w-7xl mx-auto glass-card rounded-[3rem] p-12 md:p-20 overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-[#4a9e9e]/5 to-transparent pointer-events-none" />
        
        <div className="grid md:grid-cols-2 gap-16 relative z-10">
          <div>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl font-bold text-white mb-8"
            >
              ابدأ رحلتك <span className="text-[#f9c80e]">معنا</span>
            </motion.h2>
            
            <p className="text-slate-400 mb-12 text-lg">
              هل لديك استفسار؟ فريقنا مستعد لمساعدتك في اختيار المسار الأنسب لك. تواصل معنا مباشرة عبر القنوات التالية:
            </p>

            <div className="space-y-6">
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-6 group">
                <div className="w-14 h-14 bg-green-500/10 border border-green-500/20 rounded-2xl flex items-center justify-center text-green-500 group-hover:scale-110 transition-transform">
                  <MessageCircle className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-white font-bold">واتساب</h4>
                  <p className="text-slate-500 mono">+962 7 8155 1886</p>
                </div>
              </a>

              <a href={instagramLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-6 group">
                <div className="w-14 h-14 bg-pink-500/10 border border-pink-500/20 rounded-2xl flex items-center justify-center text-pink-400 group-hover:scale-110 transition-transform">
                  <Instagram className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-white font-bold">إنستغرام</h4>
                  <p className="text-slate-500">@3_8s4</p>
                </div>
              </a>

              <a href={facebookLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-6 group">
                <div className="w-14 h-14 bg-blue-600/10 border border-blue-600/20 rounded-2xl flex items-center justify-center text-blue-500 group-hover:scale-110 transition-transform">
                  <Facebook className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-white font-bold">فيسبوك</h4>
                  <p className="text-slate-500">Koursak Indana</p>
                </div>
              </a>
            </div>

            <div className="mt-12 flex gap-4">
              <motion.a 
                href={instagramLink} target="_blank" rel="noopener noreferrer"
                whileHover={{ y: -5 }} 
                className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-white hover:text-[#4a9e9e] transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </motion.a>
              <motion.a 
                href={facebookLink} target="_blank" rel="noopener noreferrer"
                whileHover={{ y: -5 }} 
                className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-white hover:text-[#4a9e9e] transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </motion.a>
              <motion.button 
                whileHover={{ y: -5 }} 
                className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-white hover:text-[#4a9e9e] transition-colors"
              >
                <Mail className="w-5 h-5" />
              </motion.button>
            </div>
          </div>

          <div className="bg-[#071a1a]/50 p-8 rounded-3xl border border-[#4a9e9e]/20">
            <h3 className="text-xl font-bold text-white mb-6">أرسل لنا رسالة</h3>
            <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
              <div>
                <input 
                  type="text" 
                  placeholder="الاسم الكامل" 
                  className="w-full bg-[#0d2626] border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#4a9e9e] transition-all"
                />
              </div>
              <div>
                <input 
                  type="email" 
                  placeholder="البريد الإلكتروني" 
                  className="w-full bg-[#0d2626] border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#4a9e9e] transition-all"
                />
              </div>
              <div>
                <textarea 
                  rows={4} 
                  placeholder="كيف يمكننا مساعدتك؟" 
                  className="w-full bg-[#0d2626] border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#4a9e9e] transition-all resize-none"
                />
              </div>
              <button className="w-full bg-[#4a9e9e] text-[#071a1a] font-bold py-4 rounded-xl shadow-lg hover:bg-[#f9c80e] transition-all">
                إرسال الرسالة
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
