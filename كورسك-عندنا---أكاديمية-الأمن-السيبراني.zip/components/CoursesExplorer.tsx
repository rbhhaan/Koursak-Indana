
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ShieldAlert, Code, BrainCircuit, Smartphone, Layout, Cloud, 
  ArrowRight, Search, CheckCircle2, Clock, BarChart, ChevronLeft,
  Database, Globe, Monitor, PenTool, Terminal, Layers, Cpu,
  Gamepad2, Glasses, Zap, FlaskCon, Satellite, Radio,
  HardDrive, Wifi, Server, Box, Activity, GitBranch, Key, Lock,
  MousePointer2, Laptop, Network
} from 'lucide-react';

interface CourseDetail {
  id: string;
  title: string;
  level: string;
  duration: string;
  lessons: number;
  description: string;
  syllabus: string[];
}

interface Category {
  id: string;
  name: string;
  icon: React.ReactNode;
  courses: CourseDetail[];
}

const categories: Category[] = [
  {
    id: 'cyber-attack',
    name: 'الهجوم السيبراني (Red Team)',
    icon: <ShieldAlert className="w-5 h-5" />,
    courses: [
      { id: 'ca1', title: 'اختبار الاختراق المتقدم', level: 'متقدم', duration: '12 أسبوع', lessons: 45, description: 'احتراف تقنيات الاختراق الأخلاقي واكتشاف الثغرات في الأنظمة المعقدة.', syllabus: ['Metasploit Mastery', 'Active Directory Hacking', 'Advanced Exploit Dev'] },
      { id: 'ca2', title: 'الهندسة الاجتماعية المتقدمة', level: 'متوسط', duration: '6 أسابيع', lessons: 24, description: 'فهم سيكولوجية الضحية واختراق الأنظمة عبر العنصر البشري.', syllabus: ['Phishing Campaigns', 'OSINT Mastery', 'Psychological Triggers'] },
      { id: 'ca3', title: 'اختراق تطبيقات الويب', level: 'متقدم', duration: '10 أسابيع', lessons: 38, description: 'اكتشاف واستغلال ثغرات OWASP Top 10 باحترافية.', syllabus: ['SQL Injection', 'XSS advanced', 'Insecure Deserialization'] }
    ]
  },
  {
    id: 'cyber-defend',
    name: 'الدفاع السيبراني (Blue Team)',
    icon: <Lock className="w-5 h-5" />,
    courses: [
      { id: 'cd1', title: 'إدارة مراكز العمليات (SOC)', level: 'شامل', duration: '14 أسبوع', lessons: 50, description: 'مراقبة الشبكات وتحليل الحوادث الأمنية والتعامل مع التهديدات اللحظية.', syllabus: ['SIEM Implementation', 'Log Analysis', 'Incident Response'] },
      { id: 'cd2', title: 'التحقيق الجنائي الرقمي', level: 'متقدم', duration: '12 أسبوع', lessons: 40, description: 'استرجاع البيانات وتحليل الأدلة الرقمية من الأجهزة المخترقة.', syllabus: ['Memory Forensics', 'Disk Analysis', 'Malware Forensics'] }
    ]
  },
  {
    id: 'frontend',
    name: 'تطوير الواجهات (Frontend)',
    icon: <Layout className="w-5 h-5" />,
    courses: [
      { id: 'fe1', title: 'احتراف React.js الحديث', level: 'متوسط', duration: '8 أسابيع', lessons: 35, description: 'بناء واجهات تفاعلية وسريعة باستخدام أحدث تقنيات React.', syllabus: ['Hooks & Context', 'State Management', 'React Query'] },
      { id: 'fe2', title: 'تصميم الواجهات بـ Tailwind CSS', level: 'مبتدئ', duration: '4 أسابيع', lessons: 18, description: 'بناء تصاميم عصرية ومتجاوبة بسرعة مذهلة.', syllabus: ['Utility-first CSS', 'Custom Configurations', 'Responsive Design'] }
    ]
  },
  {
    id: 'backend',
    name: 'تطوير الخلفيات (Backend)',
    icon: <Terminal className="w-5 h-5" />,
    courses: [
      { id: 'be1', title: 'برمجة الخوادم بـ Node.js', level: 'متوسط', duration: '10 أسابيع', lessons: 42, description: 'بناء APIs قوية وقابلة للتوسع باستخدام JavaScript.', syllabus: ['Express.js', 'Auth (JWT/OAuth)', 'Caching with Redis'] },
      { id: 'be2', title: 'تطوير الأنظمة بـ Go (Golang)', level: 'متقدم', duration: '12 أسبوع', lessons: 48, description: 'احتراف لغة جوجل لبناء أنظمة سحابية فائقة السرعة.', syllabus: ['Concurrency/Goroutines', 'Microservices', 'GRPC'] }
    ]
  },
  {
    id: 'ai-core',
    name: 'الذكاء الاصطناعي (AI)',
    icon: <BrainCircuit className="w-5 h-5" />,
    courses: [
      { id: 'ai1', title: 'أساسيات التعلم الآلي', level: 'شامل', duration: '16 أسبوع', lessons: 60, description: 'بناء النماذج التنبؤية وفهم الخوارزميات الرياضية للذكاء الاصطناعي.', syllabus: ['Linear Regression', 'Neural Networks', 'Decision Trees'] },
      { id: 'ai2', title: 'هندسة الأوامر (Prompt Eng)', level: 'مبتدئ', duration: '3 أسابيع', lessons: 12, description: 'كيفية استغلال نماذج LLM مثل ChatGPT في الإنتاجية والبرمجة.', syllabus: ['Zero-shot prompting', 'Chain of thought', 'Auto-GPT'] }
    ]
  },
  {
    id: 'data-science',
    name: 'علم البيانات (Data Science)',
    icon: <Database className="w-5 h-5" />,
    courses: [
      { id: 'ds1', title: 'تحليل البيانات بـ Python', level: 'متوسط', duration: '10 أسابيع', lessons: 38, description: 'استخدام Pandas و Numpy لتحويل البيانات الخام إلى رؤى مفيدة.', syllabus: ['Data Cleaning', 'Visualization (Seaborn)', 'Statistical Analysis'] }
    ]
  },
  {
    id: 'cloud-aws',
    name: 'سحابة AWS',
    icon: <Cloud className="w-5 h-5" />,
    courses: [
      { id: 'aws1', title: 'AWS Solutions Architect', level: 'متقدم', duration: '12 أسبوع', lessons: 44, description: 'تصميم وإدارة البنى التحتية السحابية على أمازون.', syllabus: ['EC2 & S3', 'Lambda & Serverless', 'VPC Networking'] }
    ]
  },
  {
    id: 'devops',
    name: 'هندسة العمليات (DevOps)',
    icon: <GitBranch className="w-5 h-5" />,
    courses: [
      { id: 'do1', title: 'احتراف Docker و Kubernetes', level: 'متقدم', duration: '14 أسبوع', lessons: 52, description: 'أتمتة ونشر التطبيقات باستخدام الحاويات والأنظمة السحابية.', syllabus: ['Containerization', 'Orchestration', 'CI/CD Pipelines'] }
    ]
  },
  {
    id: 'mobile-flutter',
    name: 'تطبيقات Flutter',
    icon: <Smartphone className="w-5 h-5" />,
    courses: [
      { id: 'fl1', title: 'تطوير التطبيقات الشامل بـ Flutter', level: 'شامل', duration: '16 أسبوع', lessons: 65, description: 'بناء تطبيقات Android و iOS بكود واحد.', syllabus: ['Dart Mastery', 'State Management (Provider)', 'Firebase Integration'] }
    ]
  },
  {
    id: 'game-dev',
    name: 'تطوير الألعاب (Unity)',
    icon: <Gamepad2 className="w-5 h-5" />,
    courses: [
      { id: 'gd1', title: 'برمجة الألعاب 3D بـ Unity', level: 'شامل', duration: '20 أسبوع', lessons: 80, description: 'اصنع لعبتك الخاصة من الصفر باستخدام C# و Unity.', syllabus: ['Physics Engine', 'Game Loop', 'Scripting with C#'] }
    ]
  },
  {
    id: 'blockchain',
    name: 'البلوكشين (Web3)',
    icon: <Layers className="w-5 h-5" />,
    courses: [
      { id: 'bc1', title: 'تطوير العقود الذكية بـ Solidity', level: 'متقدم', duration: '10 أسابيع', lessons: 36, description: 'بناء تطبيقات لامركزية (DApps) على شبكة Ethereum.', syllabus: ['Smart Contracts', 'Defi Protocols', 'NFT Minting'] }
    ]
  },
  {
    id: 'networking',
    name: 'هندسة الشبكات',
    icon: <Globe className="w-5 h-5" />,
    courses: [
      { id: 'net1', title: 'أساسيات الشبكات (CCNA)', level: 'مبتدئ-متوسط', duration: '12 أسبوع', lessons: 42, description: 'فهم بروتوكولات الشبكات والراوترات والسويتشات.', syllabus: ['OSI Model', 'IP Subnetting', 'Routing Protocols'] }
    ]
  },
  {
    id: 'linux',
    name: 'أنظمة لينكس (Linux)',
    icon: <Monitor className="w-5 h-5" />,
    courses: [
      { id: 'lin1', title: 'إدارة خوادم Linux المتقدمة', level: 'شامل', duration: '8 أسابيع', lessons: 30, description: 'احتراف التعامل مع السيرفرات عبر الشاشة السوداء (CLI).', syllabus: ['Bash Scripting', 'Server Security', 'User Management'] }
    ]
  },
  {
    id: 'databases',
    name: 'إدارة قواعد البيانات',
    icon: <HardDrive className="w-5 h-5" />,
    courses: [
      { id: 'db1', title: 'إدارة PostgreSQL و SQL', level: 'متوسط', duration: '6 أسابيع', lessons: 24, description: 'إتقان لغة SQL وتنظيم البيانات بكفاءة عالية.', syllabus: ['Query Optimization', 'Relational Models', 'Transactions'] }
    ]
  },
  {
    id: 'iot',
    name: 'إنترنت الأشياء (IoT)',
    icon: <Cpu className="w-5 h-5" />,
    courses: [
      { id: 'iot1', title: 'برمجة النظم المدمجة و IoT', level: 'متقدم', duration: '14 أسبوع', lessons: 45, description: 'ربط الحساسات والقطع الإلكترونية بالإنترنت.', syllabus: ['Arduino & ESP32', 'MQTT Protocol', 'Circuit Design'] }
    ]
  },
  {
    id: 'ux-ui',
    name: 'تصميم UI/UX',
    icon: <PenTool className="w-5 h-5" />,
    courses: [
      { id: 'ux1', title: 'تصميم تجربة المستخدم بـ Figma', level: 'شامل', duration: '8 أسابيع', lessons: 32, description: 'تحويل الأفكار إلى تصاميم واجهات احترافية وقابلة للتنفيذ.', syllabus: ['User Research', 'Wireframing', 'Prototyping'] }
    ]
  },
  {
    id: 'ecommerce',
    name: 'التجارة الإلكترونية',
    icon: <MousePointer2 className="w-5 h-5" />,
    courses: [
      { id: 'ec1', title: 'بناء المتاجر بـ Shopify و Next.js', level: 'متوسط', duration: '10 أسابيع', lessons: 36, description: 'تطوير متاجر إلكترونية حديثة وسريعة جداً.', syllabus: ['Headless Commerce', 'Payment Gateway Integration', 'SEO for Stores'] }
    ]
  },
  {
    id: 'mobile-ios',
    name: 'تطبيقات iOS (Swift)',
    icon: <Laptop className="w-5 h-5" />,
    courses: [
      { id: 'ios1', title: 'احتراف Swift & SwiftUI', level: 'شامل', duration: '14 أسبوع', lessons: 55, description: 'برمجة تطبيقات آيفون وآيباد بأسلوب آبل الحديث.', syllabus: ['Swift Syntax', 'SwiftUI Views', 'Combine Framework'] }
    ]
  },
  {
    id: 'ar-vr',
    name: 'الواقع المعزز (AR/VR)',
    icon: <Glasses className="w-5 h-5" />,
    courses: [
      { id: 'ar1', title: 'تطوير تطبيقات AR بـ Unity', level: 'متقدم', duration: '12 أسبوع', lessons: 40, description: 'بناء تجارب واقع معزز للهواتف والنظارات الذكية.', syllabus: ['AR Foundation', 'Object Tracking', 'Spacial Anchors'] }
    ]
  },
  {
    id: 'qa-auto',
    name: 'أتمتة الاختبارات (QA)',
    icon: <CheckCircle2 className="w-5 h-5" />,
    courses: [
      { id: 'qa1', title: 'أتمتة الاختبارات بـ Playwright', level: 'متوسط', duration: '8 أسابيع', lessons: 28, description: 'ضمان جودة البرمجيات من خلال كتابة اختبارات آلية.', syllabus: ['E2E Testing', 'Visual Regression', 'CI Integration'] }
    ]
  },
  {
    id: 'api-eng',
    name: 'هندسة الـ API',
    icon: <Zap className="w-5 h-5" />,
    courses: [
      { id: 'api1', title: 'تصميم RESTful و GraphQL APIs', level: 'متقدم', duration: '8 أسابيع', lessons: 30, description: 'بناء واجهات برمجية معيارية وآمنة وسريعة.', syllabus: ['API Design Patterns', 'GraphQL Schemas', 'Rate Limiting & Auth'] }
    ]
  },
  {
    id: 'embedded',
    name: 'النظم المدمجة (C/C++)',
    icon: <Box className="w-5 h-5" />,
    courses: [
      { id: 'emb1', title: 'برمجة المتحكمات بـ C++', level: 'متقدم', duration: '16 أسبوع', lessons: 50, description: 'برمجة الروبوتات والأنظمة الصناعية عالية الأداء.', syllabus: ['Real-time OS', 'Hardware Abstraction', 'Memory Management'] }
    ]
  },
  {
    id: 'soft-eng',
    name: 'هندسة البرمجيات',
    icon: <GitBranch className="w-5 h-5" />,
    courses: [
      { id: 'se1', title: 'هيكلة البرمجيات وأنماط التصميم', level: 'متقدم', duration: '10 أسابيع', lessons: 35, description: 'تعلم كيف تكتب كود نظيف وقابل للصيانة.', syllabus: ['SOLID Principles', 'Design Patterns', 'Microservices Architecture'] }
    ]
  },
  {
    id: 'nlp',
    name: 'معالجة اللغات (NLP)',
    icon: <Activity className="w-5 h-5" />,
    courses: [
      { id: 'nlp1', title: 'معالجة اللغات الطبيعية بـ Transformers', level: 'متقدم', duration: '12 أسبوع', lessons: 42, description: 'بناء نماذج تفهم اللغة العربية والإنجليزية.', syllabus: ['BERT & GPT Models', 'Sentiment Analysis', 'Text Summarization'] }
    ]
  },
  {
    id: 'comp-vision',
    name: 'الرؤية الحاسوبية',
    icon: <Satellite className="w-5 h-5" />,
    courses: [
      { id: 'cv1', title: 'الرؤية الحاسوبية بـ OpenCV', level: 'متقدم', duration: '12 أسبوع', lessons: 44, description: 'تمكين الحواسيب من رؤية وفهم الصور والفيديوهات.', syllabus: ['Image Processing', 'Object Detection (YOLO)', 'Face Recognition'] }
    ]
  },
  {
    id: 'big-data',
    name: 'البيانات الضخمة',
    icon: <Radio className="w-5 h-5" />,
    courses: [
      { id: 'bd1', title: 'هندسة البيانات بـ Apache Spark', level: 'متقدم', duration: '14 أسبوع', lessons: 48, description: 'معالجة مليارات السجلات من البيانات في ثوانٍ.', syllabus: ['Distributed Computing', 'Data Lakes', 'Streaming with Kafka'] }
    ]
  },
  {
    id: 'micro-infra',
    name: 'البنية التحتية المصغرة',
    icon: <Server className="w-5 h-5" />,
    courses: [
      { id: 'mi1', title: 'إدارة الحاويات بـ Nomad و Vault', level: 'متقدم', duration: '10 أسبوع', lessons: 32, description: 'بدائل متقدمة وخفيفة لـ Kubernetes.', syllabus: ['HashiCorp Stack', 'Secrets Management', 'Service Mesh'] }
    ]
  },
  {
    id: 'crypto',
    name: 'التشفير الرقمي (Crypto)',
    icon: <Key className="w-5 h-5" />,
    courses: [
      { id: 'cr1', title: 'أساسيات التشفير وحماية البيانات', level: 'متقدم', duration: '8 أسابيع', lessons: 28, description: 'فهم خوارزميات التشفير وكيفية حماية الخصوصية.', syllabus: ['RSA & AES', 'Zero Knowledge Proofs', 'Post-Quantum Crypto'] }
    ]
  },
  {
    id: 'app-sec',
    name: 'أمن التطبيقات',
    icon: <Wifi className="w-5 h-5" />,
    courses: [
      { id: 'as1', title: 'تأمين دورة حياة البرمجيات (DevSecOps)', level: 'متقدم', duration: '12 أسبوع', lessons: 40, description: 'دمج الأمان في كل مرحلة من مراحل تطوير الكود.', syllabus: ['Static Analysis (SAST)', 'Dynamic Analysis (DAST)', 'Secure Coding'] }
    ]
  },
  {
    id: 'network-sec',
    name: 'أمن الشبكات المتقدم',
    icon: <Network className="w-5 h-5" />,
    courses: [
      { id: 'ns1', title: 'اختراق الشبكات اللاسلكية والداخلية', level: 'متقدم', duration: '10 أسبوع', lessons: 35, description: 'كشف نقاط الضعف في شبكات الشركات والمنازل.', syllabus: ['WPA3 Hacking', 'Rogue Access Points', 'Network Tunneling'] }
    ]
  }
];

interface ExplorerProps {
  onBack: () => void;
}

const CoursesExplorer: React.FC<ExplorerProps> = ({ onBack }) => {
  const [selectedCat, setSelectedCat] = useState<string>('cyber-attack');
  const [selectedCourse, setSelectedCourse] = useState<CourseDetail | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const currentCategory = useMemo(() => categories.find(c => c.id === selectedCat), [selectedCat]);
  
  const handleEnroll = () => {
    if (!selectedCourse) return;
    const message = encodeURIComponent(`مرحباً أكاديمية كورسك عندنا، أود الاشتراك في مسار: ${selectedCourse.title} ضمن تصنيف ${currentCategory?.name}`);
    window.open(`https://wa.me/message/VBFZEYE4ZZZWA1?text=${message}`, '_blank');
  };

  const filteredCourses = useMemo(() => {
    if (!currentCategory) return [];
    return currentCategory.courses.filter(course => 
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [currentCategory, searchQuery]);

  return (
    <div className="pt-32 pb-24 px-4 md:px-6 min-h-screen bg-[#071a1a]">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <button 
              onClick={onBack}
              className="flex items-center gap-2 text-[#4a9e9e] hover:text-[#f9c80e] transition-colors mb-4 group font-bold"
            >
              <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              العودة للرئيسية
            </button>
            <h1 className="text-3xl md:text-5xl font-black text-white mb-2">الجامعة التقنية الكبرى</h1>
            <p className="text-slate-400 font-medium">استكشف 30 تخصصاً تقنياً وباشر رحلة احترافك العالمية.</p>
          </motion.div>
          
          <div className="relative group max-w-sm w-full">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
            <input 
              type="text" 
              placeholder="ابحث عن مهارة أو دورة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#0d2626] border border-slate-800 rounded-2xl py-4 pr-12 pl-4 text-white focus:outline-none focus:border-[#4a9e9e] transition-all shadow-xl"
            />
          </div>
        </div>

        {/* Categories Tab Bar */}
        <div className="flex gap-4 mb-12 overflow-x-auto pb-6 no-scrollbar snap-x">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setSelectedCat(cat.id);
                setSelectedCourse(null);
                setSearchQuery('');
              }}
              className={`flex items-center gap-3 px-6 py-4 rounded-2xl border transition-all whitespace-nowrap font-bold snap-start
                ${selectedCat === cat.id 
                  ? 'bg-[#4a9e9e] text-[#071a1a] border-[#4a9e9e] shadow-[0_0_20px_rgba(74,158,158,0.3)] scale-105' 
                  : 'bg-[#0d2626] text-slate-400 border-slate-800 hover:border-[#4a9e9e]/40'
                }`}
            >
              <span className={selectedCat === cat.id ? 'text-[#071a1a]' : 'text-[#4a9e9e]'}>{cat.icon}</span>
              {cat.name}
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Courses List */}
          <div className="lg:col-span-2 space-y-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedCat + searchQuery}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="grid gap-6"
              >
                {filteredCourses && filteredCourses.length > 0 ? (
                  filteredCourses.map((course) => (
                    <motion.div
                      key={course.id}
                      whileHover={{ scale: 1.01 }}
                      onClick={() => setSelectedCourse(course)}
                      className={`p-6 md:p-8 rounded-[2rem] border cursor-pointer transition-all group relative overflow-hidden
                        ${selectedCourse?.id === course.id 
                          ? 'bg-[#1a3d3d] border-[#4a9e9e] shadow-[0_0_30px_rgba(74,158,158,0.15)]' 
                          : 'bg-[#0d2626] border-slate-800 hover:border-[#4a9e9e]/30'
                        }`}
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-3 mb-4">
                            <span className="text-[10px] font-black tracking-widest text-[#f9c80e] uppercase bg-[#f9c80e]/10 px-3 py-1 rounded-full border border-[#f9c80e]/20">
                              {course.level}
                            </span>
                            <span className="text-xs text-slate-500 flex items-center gap-1 font-bold">
                              <Clock className="w-3 h-3" />
                              {course.duration}
                            </span>
                          </div>
                          <h3 className="text-xl md:text-2xl font-black text-white mb-2 group-hover:text-[#4a9e9e] transition-colors">
                            {course.title}
                          </h3>
                          <p className="text-slate-400 text-sm leading-relaxed max-w-xl">
                            {course.description}
                          </p>
                        </div>
                        <div className="flex-shrink-0 flex items-center justify-center">
                          <div className={`w-12 h-12 rounded-full border border-[#4a9e9e]/30 flex items-center justify-center transition-all duration-300 ${selectedCourse?.id === course.id ? 'bg-[#f9c80e] text-[#071a1a] border-[#f9c80e] rotate-90' : 'text-[#4a9e9e] group-hover:bg-[#4a9e9e]/10'}`}>
                            <ArrowRight className="w-6 h-6" />
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="py-24 text-center bg-[#0d2626]/40 rounded-[2.5rem] border border-dashed border-slate-800">
                    <Search className="w-12 h-12 text-slate-700 mx-auto mb-4" />
                    <p className="text-slate-500 font-bold text-lg">لم نعثر على مسارات مطابقة لبحثك في هذا القسم.</p>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Detailed Sidebar */}
          <div className="lg:col-span-1">
            <AnimatePresence>
              {selectedCourse ? (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-[#0d2626] border border-[#4a9e9e]/30 rounded-[2.5rem] p-8 md:p-10 sticky top-32 shadow-2xl"
                >
                  <h4 className="text-[#f9c80e] font-black text-xl mb-8 flex items-center gap-3">
                    <BarChart className="w-6 h-6" />
                    مفردات المسار
                  </h4>
                  
                  <div className="space-y-6 mb-10">
                    {selectedCourse.syllabus.map((item, i) => (
                      <div key={i} className="flex gap-5 group/item">
                        <div className="w-7 h-7 rounded-lg bg-[#4a9e9e]/15 flex items-center justify-center flex-shrink-0 text-[#4a9e9e] text-xs font-black border border-[#4a9e9e]/20 group-hover/item:bg-[#4a9e9e] group-hover/item:text-[#071a1a] transition-all">
                          {i + 1}
                        </div>
                        <p className="text-slate-300 text-sm font-medium leading-relaxed">{item}</p>
                      </div>
                    ))}
                  </div>

                  <div className="bg-[#071a1a] rounded-[1.5rem] p-6 mb-10 border border-slate-800 relative overflow-hidden">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-slate-500 text-[10px] font-black uppercase tracking-widest">كثافة المحتوى</span>
                      <span className="text-white font-black text-sm">{selectedCourse.lessons} درساً تطبيقياً</span>
                    </div>
                    <div className="w-full bg-slate-800/50 h-2 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: "85%" }}
                        transition={{ duration: 1.5, ease: "easeOut" }}
                        className="bg-gradient-to-r from-[#4a9e9e] to-[#f9c80e] h-full" 
                      />
                    </div>
                  </div>

                  <button 
                    onClick={handleEnroll}
                    className="w-full bg-[#4a9e9e] text-[#071a1a] font-black py-5 rounded-[1.5rem] hover:bg-[#f9c80e] transition-all flex items-center justify-center gap-3 group shadow-[0_15px_30px_rgba(74,158,158,0.3)] active:scale-95"
                  >
                    اشترك الآن في المسار
                    <CheckCircle2 className="w-6 h-6 group-hover:scale-110 transition-transform" />
                  </button>
                  <p className="text-[10px] text-center text-slate-500 mt-5 font-bold italic">سيتم تحويلك مباشرة لمسؤول القبول عبر واتساب</p>
                </motion.div>
              ) : (
                <div className="bg-[#0d2626]/30 border border-dashed border-slate-800 rounded-[2.5rem] p-12 text-center h-[500px] flex flex-col items-center justify-center">
                  <div className="w-20 h-20 bg-slate-800/30 rounded-full flex items-center justify-center text-slate-700 mb-6 animate-pulse">
                    <Layers className="w-10 h-10" />
                  </div>
                  <p className="text-slate-500 font-black text-lg max-w-[200px] mx-auto leading-relaxed">
                    اختر تخصصاً لمشاهدة المنهج الدراسي وخيارات الاشتراك
                  </p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CoursesExplorer;
